
package com.company;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class S23012 {
    public static void main(String[] args) throws IOException {
        String param = args[0];
        Radar radar = new Radar();
        Aircraft[] newAircraft = {new CargoAirPlane("CargoAirPlane", "W-1", "An-225", "left", 0, 0, 0, 800, 70000),
                new CargoAirPlane("CargoAirPlane", "W-2", "An-125", "left", 0, 0, 0, 800, 7590),
                new CargoAirPlane("CargoAirPlane", "W-3", "An-12", "right", 0, 0, 0, 800, 800),
                new PassengerAirPlane("PassengerAirPlane", "W-4", "A-320", "right", 0, 0, 0, 800, 100),
                new PassengerAirPlane("PassengerAirPlane", "W-5", "Boeing-737", "right", 0, 0, 0, 240, 120),
                new PassengerAirPlane("PassengerAirPlane", "W-6", "Embraer-E195", "right", 0, 0, 0, 800, 40),
                new PassengerAirPlane("PassengerAirPlane", "W-7", "A-321", "right", 0, 0, 0, 800, 300),
                new MilitaryAirPlane("MilitaryAirPlane", "W-8", "F-16", "right", 0, 0, 0, 800, 2000),
                new MilitaryAirPlane("MilitaryAirPlane", "W-9", "F-22", "right", 0, 0, 0, 800, 6000),
                new MilitaryAirPlane("MilitaryAirPlane", "W-10", "F-18", "right", 0, 0, 0, 800, 3000)};
        switch (param) {
            case "save": {
                radar.save(newAircraft);
                break;
            }
            case "load": {
                radar.load();
                radar.setRandomParameters();
                radar.sortAirPlanesByDistance();
                int maxDistance = radar.getMaxDistance();
                int zonesCount = radar.getZonesCount(maxDistance);
                String[][] res = new String[zonesCount][];
                for (int i = 0; i < zonesCount; i++) {
                    res[i] = radar.getAllAircraftInCurrentZone(i);
                }

                for (int i = 0; i < res.length; i++) {
                    System.out.println("Zone a" + i + " between " + (int) Math.pow(3, i) + "km and " + (int) Math.pow(3, i + 1) + "km : ");
                    for (int j = 0; j < res[i].length; j++) {
                        System.out.println(res[i][j]);
                    }
                    System.out.println();
                }
                break;
            }
        }
    }
}

class Radar {
    Aircraft[] aircraftArr = new Aircraft[10];
    int aircraftArrIndex = 0;

    int getHorizontalDistance(int x, int y) {
        int hd = (int) Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        return hd;
    }

    int geRealDistance(int x, int y, int flyAltitude) {
        int rd = (int) Math.sqrt(Math.pow(getHorizontalDistance(x, y), 2) + Math.pow(flyAltitude, 2));
        return rd;
    }

    int getMaxDistance() {
        for (int i = 0; i < this.aircraftArr.length; i++) {
            System.out.println("Distance: " + (int) Math.sqrt(Math.pow(getHorizontalDistance(this.aircraftArr[i].x, this.aircraftArr[i].y), 2) + Math.pow(this.aircraftArr[i].flyAltitude, 2)));
        }
        int rd = (int) Math.sqrt(Math.pow(getHorizontalDistance(this.aircraftArr[this.aircraftArr.length - 1].x, this.aircraftArr[this.aircraftArr.length - 1].y), 2) + Math.pow(this.aircraftArr[this.aircraftArr.length - 1].flyAltitude, 2));
        System.out.println("MAX :" + rd);
        return rd;
    }

    int getZonesCount(int maxDistance) {
        int zonesCount = 0;
        while ((int) (Math.pow(3, zonesCount) * 1000) < maxDistance) {
            zonesCount++;
        }
        return zonesCount;
    }

    int getAircraftCountInCurrentZone(int zone) {
        int count = 0;
        for (int i = 0; i < this.aircraftArr.length; i++) {
            if ((Math.pow(3, zone) * 1000) < this.geRealDistance(this.aircraftArr[i].x, this.aircraftArr[i].y, this.aircraftArr[i].flyAltitude)
                    && (Math.pow(3, zone + 1) * 1000) > this.geRealDistance(this.aircraftArr[i].x, this.aircraftArr[i].y, this.aircraftArr[i].flyAltitude)) {
                count++;
            }
        }
        return count;
    }

    String[] getAllAircraftInCurrentZone(int zone) {
        int aircraftCount = getAircraftCountInCurrentZone(zone);
        String[] result = new String[aircraftCount];
        int index = 0;
        for (int i = 0; i < this.aircraftArr.length; i++) {
            if ((Math.pow(3, zone) * 1000) < this.geRealDistance(this.aircraftArr[i].x, this.aircraftArr[i].y, this.aircraftArr[i].flyAltitude)
                    && (Math.pow(3, zone +1) * 1000) > this.geRealDistance(this.aircraftArr[i].x, this.aircraftArr[i].y, this.aircraftArr[i].flyAltitude)) {
                result[index] = this.aircraftArr[i].getInfo();
                index++;
            }
        }
        return result;
    }

    void sortAirPlanesByDistance() {
        for (int i = 0; i < this.aircraftArr.length; i++) {
            for (int j = 0; j < this.aircraftArr.length; j++) {
                if (geRealDistance(this.aircraftArr[i].x, this.aircraftArr[i].y, this.aircraftArr[i].flyAltitude) < geRealDistance(this.aircraftArr[j].x, this.aircraftArr[j].y, this.aircraftArr[j].flyAltitude)) {
                    Aircraft tmp = this.aircraftArr[i];
                    this.aircraftArr[i] = this.aircraftArr[j];
                    this.aircraftArr[j] = tmp;
                }
            }
        }
    }

    public void addAirCraftToArray(String line) {
        String[] strArr = line.split(",");
        switch (strArr[0]) {
            case "CargoAirPlane":
                this.aircraftArr[this.aircraftArrIndex] = new CargoAirPlane(strArr[0], strArr[1], strArr[2], strArr[3], Integer.valueOf(strArr[4]), Integer.valueOf(strArr[5]), Integer.valueOf(strArr[6]), Integer.valueOf(strArr[7]), Integer.valueOf(strArr[8]));
                this.aircraftArrIndex++;
                break;
            case "PassengerAirPlane":
                this.aircraftArr[this.aircraftArrIndex] = new PassengerAirPlane(strArr[0], strArr[1], strArr[2], strArr[3], Integer.valueOf(strArr[4]), Integer.valueOf(strArr[5]), Integer.valueOf(strArr[6]), Integer.valueOf(strArr[7]), Integer.valueOf(strArr[8]));
                this.aircraftArrIndex++;
                break;
            case "MilitaryAirPlane":
                this.aircraftArr[this.aircraftArrIndex] = new MilitaryAirPlane(strArr[0], strArr[1], strArr[2], strArr[3], Integer.valueOf(strArr[4]), Integer.valueOf(strArr[5]), Integer.valueOf(strArr[6]), Integer.valueOf(strArr[7]), Integer.valueOf(strArr[8]));
                this.aircraftArrIndex++;
                break;
            default:
                System.out.println("Unknown aircraft type");
                break;
        }
    }

    public void setRandomParameters() {
        for (int i = 0; i < this.aircraftArr.length; i++) {
            this.aircraftArr[i].setRandomX();
            this.aircraftArr[i].setRandomY();
            this.aircraftArr[i].setRandomFlyAltitude();
        }
    }

    public void save(Aircraft[] aircraftArr) throws IOException {
        FileOutputStream file = new FileOutputStream("air.txt", false);
        try {
            for (int i = 0; i < aircraftArr.length; i++) {
                byte[] res = aircraftArr[i].getInfo().getBytes();
                file.write(res);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            file.close();
        }
    }

    public void load() throws IOException {

        FileInputStream reader = new FileInputStream("air.txt");
        try {
            BufferedReader bf = new BufferedReader(new InputStreamReader(reader));
            String line;
            while ((line = bf.readLine()) != null) {
                this.addAirCraftToArray(line);
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            reader.close();
        }
    }
}

class Aircraft {
    int x;
    int y;
    String flyVector;
    int flyAltitude;
    int flySpeed;
    String flyId;
    String airPlaneType;
    String destinationType;

    Aircraft(String destinationType, String airPlaneType, String flyId, String flyVector, int x, int y, int flyAltitude, int flySpeed) {
        this.destinationType = destinationType;
        this.x = x;
        this.y = y;
        this.flyId = flyId;
        this.airPlaneType = airPlaneType;
        this.flyVector = flyVector;
        this.flyAltitude = flyAltitude;
        this.flySpeed = flySpeed;
    }

    public String getInfo() {
        return this.airPlaneType + ", " + this.flyId + ", " + this.flyVector + ", " + this.flyAltitude + ", " + this.flySpeed + ", " + this.x + ", " + this.y;
    }

    public void setRandomX() {
        this.x = (int) (Math.random() * 10000);
    }

    public void setRandomY() {
        this.y = (int) (Math.random() * 10000);
    }

    public void setRandomFlyAltitude() {
        this.flyAltitude = (int) (Math.random() * 10000);
    }
}

class CargoAirPlane extends Aircraft {
    int cargoWeight;

    CargoAirPlane(String destinationType, String airPlaneType, String flyId, String flyVector, int x, int y, int flyAltitude, int flySpeed, int cargoWeight) {
        super(destinationType, airPlaneType, flyId, flyVector, x, y, flyAltitude, flySpeed);
        this.cargoWeight = cargoWeight;
    }

    @Override
    public void setRandomFlyAltitude() {
        this.flyAltitude = (int) (Math.random() * 7000);
    }

    @Override
    public String getInfo() {
        return super.getInfo() + ", CargoWeight: " + this.cargoWeight + "kg";
    }
}

class PassengerAirPlane extends Aircraft {
    int passangerCount;

    PassengerAirPlane(String destinationType, String airPlaneType, String flyId, String flyVector, int x, int y, int flyAltitude, int flySpeed, int passangerCount) {
        super(destinationType, airPlaneType, flyId, flyVector, x, y, flyAltitude, flySpeed);
        this.passangerCount = passangerCount;
    }

    @Override
    public void setRandomFlyAltitude() {
        this.flyAltitude = (int) (Math.random() * 11000);
    }

    @Override
    public String getInfo() {
        return super.getInfo() + ", PassangersCount: " + this.passangerCount;
    }
}

class MilitaryAirPlane extends Aircraft {
    int combatWeight;

    MilitaryAirPlane(String destinationType, String airPlaneType, String flyId, String flyVector, int x, int y, int flyAltitude, int flySpeed, int combatWeight) {
        super(destinationType, airPlaneType, "UnknownId", flyVector, x, y, flyAltitude, flySpeed);
        this.combatWeight = combatWeight;
    }

    @Override
    public void setRandomFlyAltitude() {
        this.flyAltitude = (int) (Math.random() * 20000);
    }

    @Override
    public String getInfo() {
        return super.getInfo() + ", CombatWeight: " + this.combatWeight + "kg";
    }
}